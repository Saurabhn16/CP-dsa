#include <bits/stdc++.h>
using namespace std;
void solve(){
    int n;
    cin>>n;

    vector<string>v;
    for(int i=0;i<n;i++){
        string s;
        cin>>s;
        v.push_back(s);
    }
    int k;
    cin>>k;
    map<string,int>m;
    for(int i=0;i<n;i++){
        m[v[i]]++;
    }
    // vector< pair<int,string> >v;
    vector< pair <int,string> > ve;
    for(auto& x:m){
        // pair<int,string>p=make_pair(-1*x.second,x.first);
        ve.push_back({-1*x.second,x.first});
    }
    sort(ve.begin(),ve.end());
    for(int i=0;i<k;i++){
        cout<<ve[i].second<<endl;
    }

}

int main() {
	// your code goes here
	int t=1;
	// cin>>t;
	while(t--){
	    solve();
	}
	return 0;
}


//time complexity--O(nlong)
//space complexity--O(n)